'use client'
import Link from "next/link";

export default function ListPage({data}) {

  async function deletePost(id){
    await fetch(`/api/board/${id}`,{
      method:"DELETE"
    });
    console.log("삭제 완료");
  }

  return(
      <div>
         {data.map((itme)=>(
            <div className="list-item" key={itme.id}>
               <div>
                  <Link href={`/detail/${itme.id}`} className="list-btn">
                     <h4>{itme.title}</h4>
                  </Link>

               </div>

               <div>

                  <Link href={`/edit/${itme.id}`} className="list-btn">✏️</Link>
               </div>
               <span onClick={()=> deletePost(itme.id)}>
                  🗑️
               </span>
            </div>
         ))}
      </div>
  )
}
