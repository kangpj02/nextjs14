import { db } from "@/lib/database";

export default function Home() {


   return (
      <div>
         ff
      </div>
   );
}
