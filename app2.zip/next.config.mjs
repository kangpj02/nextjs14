/** @type {import('next').NextConfig} */
const nextConfig = {

experimental:{
  optimizePackageImports:["next/link"]
}




};


export default nextConfig;
