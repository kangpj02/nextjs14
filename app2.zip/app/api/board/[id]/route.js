import { NextResponse } from "next/server"



export async function POST(req, {params}){
   
   // const body = await req.json()

   console.log("aaaaa",params)

   return NextResponse.json({

      result: true
   }

   )


}


