import { db } from "@/lib/database";



export default async function Detail({params}) {

   const sql = "SELECT * FROM test where id = ? ";
   const rows = await db(sql, [params.id]);

   console.log(rows)



  return (
    <div>
      <h4>상세페이지임</h4>
      <h4>{rows[0].title}</h4>
      <p>{rows[0].content}</p>
    </div>
  )
}


